<template>
  <div>
    基础数据录入
  </div>
</template>
<script>
export default {

}
</script>
